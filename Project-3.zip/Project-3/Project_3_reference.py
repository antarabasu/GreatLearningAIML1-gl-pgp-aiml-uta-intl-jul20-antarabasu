
# Using the data collected from existing customers,
# build a model that will help the marketing team identify potential customers who are relatively more likely to subscribe term deposit
# and thus increase their hit ratio.

# Univariate analysis

# Univariate analysis – data types and description of the independent attributes which should include
# (name, meaning, range of values observed, central values (mean and median), standard deviation and quartiles,
# analysis of the body of distributions / tails, missing values, outliers.

import numpy as np
import pandas as pd

# importing ploting libraries
import matplotlib.pyplot as plt

#importing seaborn for statistical plots
import seaborn as sns

Item = pd.read_csv('C:/Users/antarab/Desktop/Tech/PGP-COURSE(AI.ML)/Project-3/bank-full.csv')
print(Item.head())

# data types of each column
print(Item.info())
print(Item.dtypes)

# meaning of each independent variable

# age           int64
# job          object
# marital      object
# education    object
# default      object
# balance       int64
# housing      object
# loan         object
# contact      object
# day           int64
# month        object
# duration      int64
# campaign      int64
# pdays         int64
# previous      int64
# poutcome     object
# Target       object


#Convert variable to a categorical variable wherever relevant
Item['day'] = Item['day'].astype('category')
Item['job'] = Item['job'].astype('category')

Item['marital'] = Item['marital'].astype('category')
Item['education'] = Item['education'].astype('category')
Item['default'] = Item['default'].astype('category')
Item['housing'] = Item['housing'].astype('category')
Item['loan'] = Item['loan'].astype('category')
Item['contact'] = Item['contact'].astype('category')
Item['month'] = Item['month'].astype('category')
Item['poutcome'] = Item['poutcome'].astype('category')
Item['Target'] = Item['Target'].astype('category')


# description: name, range ( max- min ), mean, median (50%), std dev, quartiles( 25%- 50%- 75%)
print(Item.describe().T)


for col in ['job','marital','education','default','housing','loan','contact','month','poutcome','Target']:
    print('Distribution of ', col,':', Item[col].value_counts(normalize=True))

# # bank client data:
# 1 - age (numeric)
# 2 - job : type of job (categorical: 'admin.','blue-collar','entrepreneur','housemaid','management','retired','self-employed','services','student','technician','unemployed','unknown')
# 3 - marital : marital status (categorical: 'divorced','married','single')
# 4 - education (categorical: 'secondary','tertiary','primary','unknown')

# 5 - default: has credit in default? (categorical: 'no','yes')
# 6 - balance: balance in the account : numeric
# 7 - housing: has housing loan? (categorical: 'no','yes')
# 8 - loan: has personal loan? (categorical: 'no','yes')

# # related with the last contact of the current campaign:
# 9 - contact: contact communication type (categorical: 'cellular','telephone','unknown')
# 10 - day is day_of_week: last contact day of the week (categorical: 'mon','tue','wed','thu','fri')// need to convert into categorical from numeric




# 11 - month: last contact month of year (categorical: 'jan', 'feb', 'mar', ..., 'nov', 'dec')
# 12 - duration: last contact duration, in seconds (numeric).
# # other attributes:
# 13 - campaign: number of contacts performed during this campaign and for this client (numeric, includes last contact)
# 14 - pdays: number of days that passed by after the client was last contacted from a previous campaign (numeric; -1 means client was not previously contacted)
# 15 - previous: number of contacts performed before this campaign and for this client (numeric)
# 16 - poutcome: outcome of the previous marketing campaign (categorical: 'failure','unknown','success','other')




# Output variable (desired target):
# 17 - Target - has the client subscribed a term deposit? (binary: 'yes','no')
# any missing values
print('*** Missing Values ***')
print(Item.isnull().values.any())


# Strategies to address the different data challenges such as data pollution, outlier’s treatment and missing values treatment.

# There is no missing value in this dataset. Nevertheless, there are values like “unknown”, “others”, which are just like missing values.
# Thus, these ambiguous values are removed from the dataset.

# Step 1: Delete the rows which column 'poutcome' contains 'other', as 'other' doesn't add any value here
condition = Item.poutcome == 'other'
dataset2 = Item.drop(Item[condition].index, axis = 0, inplace = False)

# Step 2: Replace 'unknown' in job and education with 'other'
Item['job'].replace({'unknown':'other'}, inplace = True)

Item['education'].replace({'unknown':'other'}, inplace = True)

 # Univariate: distribution plot

# # distplot for continous columns, ID is just an identifier so exluding
# for col in pdata.columns.values.tolist():
for col in ['age','balance','duration','campaign','pdays','previous']:
    sns.distplot(Item[col])
    plt.show()


# OUTLIERS- BALANCE DO !!!!
# Please provide comments in jupyter notebook regarding the steps you take and insights drawn from the plots.
# COPY FROM https://github.com/LaxmiChaudhary/Ensemble-Techniques-on-Bank-Data/blob/master/Ensemble%20Techniques%20on%20Bank%20dataset.ipynb


# 2. Multivariate analysis (8 marks)
# a. Bi-variate analysis between the predictor variables and target column. Comment on your findings in terms of their relationship and degree of relation if any.
# Visualize the analysis using boxplots and pair plots, histograms or density curves. Select the most appropriate attributes.
# b. Please provide comments in jupyter notebook regarding the steps you take and insights drawn from the plots
# https://github.com/LaxmiChaudhary/Ensemble-Techniques-on-Bank-Data/blob/master/Ensemble%20Techniques%20on%20Bank%20dataset.ipynb

plt.figure(figsize = (15,7))
plt.title('Correlation of Attributes', y=1.05, size=19)
sns.heatmap(Item.corr(), cmap='plasma',annot=True, fmt='.2f')



# Deliverable – 2 (Prepare the data for analytics) – (10)
# 1. Ensure the attribute types are correct. If not, take appropriate actions.
# 2. Get the data model ready.
# 3. Transform the data i.e. scale / normalize if required
# 4. Create the training set and test set in ratio of 70:30

#importing the Encoding library
from sklearn.preprocessing import LabelEncoder

#Import SMOTE library for handling imbalance class
# from imblearn.over_sampling import SMOTE

#Import Decision Tree Classifier machine learning Library
from sklearn.tree import DecisionTreeClassifier

# Import Logistic Regression machine learning library
from sklearn.linear_model import LogisticRegression

#Import Naive Bayes' machine learning Library
from sklearn.naive_bayes import GaussianNB

#Import Sklearn package's data splitting function which is based on random function
from sklearn.model_selection import train_test_split

#Import the metrics
from sklearn import metrics

#Import the Voting classifier for Ensemble
from sklearn.ensemble import VotingClassifier

#independent and dependent variables
X=Item.loc[:,Item.columns!='Target']
y=Item.loc[:,Item.columns=='Target']


# Split X and y into training and test set in 70:30 ratio
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=0)
columns=X_train.columns

################################################# till this much done ######################################################################################
# First create models using Logistic Regression and Decision Tree algorithm. Note the model performance
# by using different matrices. Use confusion matrix to evaluate class level metrics i.e. Precision/Recall.
# Also reflect the accuracy and F1 score of the model. (10 marks)

# https://www.kaggle.com/yufengsui/ml-project-bank-telemarketing-analysis



# Build the ensemble models (Bagging and Boosting) and note the model performance by using different matrices.
# Use same metrics as in above model. (at least 3 algorithms) (15 marks)



# variables:
# Bank client data:
# 1. age: Continuous feature
# 2. job: Type of job (management, technician, entrepreneur, blue-collar, etc.)
# 3. marital: marital status (married, single, divorced)
# 4. education: education level (primary, secondary, tertiary)
# 5. default: has credit in default?
# 6. housing: has housing loan?
# 7. loan: has personal loan?
# 8. balance in account
# Related to previous contact:
# 9. contact: contact communication type
# 10. month: last contact month of year
# 11. day: last contact day of the month
# 12. duration: last contact duration, in seconds*
# Other attributes:
# 13. campaign: number of contacts performed during this campaign and for this client
# 14. pdays: number of days that passed by after the client was last contacted from a previous campaign (-1 tells us the person has not been contacted or contact period is beyond 900 days)
# 15. previous: number of times the client has been contacted before for the last campaign to subscribe term deposit
# 16. poutcome: outcome of the previous marketing campaign
# Output variable (desired target):
# 17. Target: Tell us has the client subscribed a term deposit. (Yes, No)



# Make a DataFrame to compare models and their metrics. Give conclusion regarding the best algorithm and your reason behind it.

# https://github.com/LaxmiChaudhary/Ensemble-Techniques-on-Bank-Data/blob/master/Ensemble%20Techniques%20on%20Bank%20dataset.ipynb: POINT-7
#OR
# https://www.kaggle.com/yufengsui/ml-project-bank-telemarketing-analysis, Compare regression algorithms



# After managing the imbalancing the target column and scaling the columns, we are getting the highest accuracy using Random Forest and Bagging Models.
# It means that the models will predict 89% correctly the customers who will subscribe term deposit and who will not.
# These models will perfrom well as compared to imbalanced class models.